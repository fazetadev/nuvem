/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import { useI18n } from './i18n.tsx';
import confetti from 'canvas-confetti';
import { Header } from './components/Header.tsx';
import { Hero } from './components/Hero.tsx';
import { PlayerIdStep } from './components/PlayerIdStep.tsx';
import { PackagesGrid } from './components/PackagesGrid.tsx';
import { PaymentStep } from './components/PaymentStep.tsx';
import { CheckoutSummaryModal } from './components/CheckoutSummaryModal.tsx';
import { OrderSuccessModal } from './components/OrderSuccessModal.tsx';
import { OrderTrackerModal } from './components/OrderTrackerModal.tsx';
import { HowItWorks } from './components/HowItWorks.tsx';
import { TrustAndFaqSection } from './components/TrustAndFaqSection.tsx';
import { GameSelector } from './components/GameSelector.tsx';
import { StarParticles } from './components/StarParticles.tsx';
import { HalloweenBackdrop, Graveyard } from './components/HalloweenDecor.tsx';
import { StatsStrip, WhyUs, PaymentsStrip, FinalCTA } from './components/ExtraSections.tsx';
import { Footer } from './components/Footer.tsx';
import { DiamondPackage, PaymentMethod, OrderRecord, GameId } from './types/store.ts';
import {
  DIAMOND_PACKAGES,
  ROBLOX_PACKAGES,
  GAME_INFO,
  PAYMENT_METHODS,
  validateAccount,
  generateOrderId,
  saveOrder,
} from './utils/rechargeLogic.ts';
import { AlertCircle, Sparkles, MessageCircle } from 'lucide-react';

export default function App() {
  const { t } = useI18n();
  // Form State: Free Fire UID (Direct, no server picker)
  const [game, setGame] = useState<GameId>('freefire');
  const [playerId, setPlayerId] = useState('');
  
  // Default selected package: 520 diamonds ($16.000 COP) as recommended standard
  const [selectedPackage, setSelectedPackage] = useState<DiamondPackage | null>(DIAMOND_PACKAGES[2]);
  
  // Default payment: Nequi
  const [selectedPayment, setSelectedPayment] = useState<PaymentMethod | null>(PAYMENT_METHODS[0]);
  
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');

  // Modals
  const [isSummaryOpen, setIsSummaryOpen] = useState(false);
  const [isSuccessOpen, setIsSuccessOpen] = useState(false);
  const [isTrackerOpen, setIsTrackerOpen] = useState(false);
  const [currentOrder, setCurrentOrder] = useState<OrderRecord | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [validationAlert, setValidationAlert] = useState<string | null>(null);

  const rechargeSectionRef = useRef<HTMLDivElement>(null);

  const handleSelectGame = (g: GameId) => {
    if (g === game) return;
    setGame(g);
    setPlayerId('');
    setValidationAlert(null);
    setSelectedPackage(g === 'roblox' ? ROBLOX_PACKAGES[3] : DIAMOND_PACKAGES[2]);
  };

  // Aparición suave de secciones al hacer scroll (solo opacity/transform: barato)
  useEffect(() => {
    if (!('IntersectionObserver' in window)) return;
    if (window.matchMedia?.('(prefers-reduced-motion: reduce)').matches) return;
    const els = Array.from(document.querySelectorAll<HTMLElement>(
      '#beneficios .grid > *, #como-funciona .grid > *, #faq .grid > *, #faq .space-y-3 > *'
    ));
    const io = new IntersectionObserver((entries) => {
      entries.forEach((e) => {
        if (e.isIntersecting) { e.target.classList.add('reveal-in'); io.unobserve(e.target); }
      });
    }, { rootMargin: '0px 0px -8% 0px', threshold: 0.05 });
    els.forEach((el, i) => {
      el.classList.add('reveal');
      el.style.transitionDelay = `${(i % 6) * 60}ms`;
      io.observe(el);
    });
    return () => io.disconnect();
  }, []);

  const scrollToRecharge = () => {
    rechargeSectionRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleOpenProceed = () => {
    setValidationAlert(null);
    const idValidation = validateAccount(game, playerId);
    if (game === 'freefire' && !idValidation.isValid) {
      setValidationAlert(t(idValidation.error || 'Por favor ingresa tu ID'));
      scrollToRecharge();
      return;
    }
    if (!selectedPackage) {
      setValidationAlert(t('Por favor selecciona un paquete de {item}', { item: t(GAME_INFO[game].unitLower) }));
      scrollToRecharge();
      return;
    }
    if (!selectedPayment) {
      setValidationAlert(t('Por favor selecciona un método de pago'));
      return;
    }
    if (!phone.trim()) {
      setValidationAlert(t('Por favor ingresa tu número de WhatsApp para enviarte el comprobante'));
      return;
    }

    setIsSummaryOpen(true);
  };

  const handleConfirmOrder = () => {
    if (!selectedPackage || !selectedPayment) return;
    setIsSubmitting(true);

    setTimeout(() => {
      const newOrderId = generateOrderId();
      const orderData: OrderRecord = {
        orderId: newOrderId,
        playerId: game === 'roblox' ? '' : playerId.trim(),
        packageId: selectedPackage.id,
        packageName: `${selectedPackage.diamonds} ${GAME_INFO[game].unit}`,
        game,
        diamonds: selectedPackage.diamonds,
        totalCOP: selectedPackage.priceCOP,
        totalUSD: selectedPackage.priceUSD,
        paymentMethodId: selectedPayment.id,
        paymentMethodName: selectedPayment.name,
        customerPhone: phone.trim(),
        customerEmail: email.trim(),
        status: 'PENDIENTE',
        createdAt: new Date().toISOString(),
      };

      saveOrder(orderData);
      setCurrentOrder(orderData);
      setIsSubmitting(false);
      setIsSummaryOpen(false);
      setIsSuccessOpen(true);

      // Trigger celebratory confetti in purple and gold
      try {
        confetti({
          particleCount: 90,
          spread: 80,
          origin: { y: 0.6 },
          colors: ['#a855f7', '#7c3aed', '#ec4899', '#fbbf24', '#ffffff'],
        });
      } catch (err) {
        console.log('Confetti effect triggered', err);
      }
    }, 500);
  };

  return (
    <>
    <StarParticles />
    <HalloweenBackdrop />
    <div className="relative z-10 min-h-screen text-slate-100 flex flex-col selection:bg-purple-600 selection:text-white">
      <div className="relative z-50 bg-gradient-to-r from-orange-700 via-orange-500 to-purple-700 text-white text-center text-[11px] sm:text-xs font-bold tracking-wide py-1.5 px-3">
        {t('🎃 Especial Halloween en Nuvem Store 🦇 Recarga tus {item} esta noche de terror 👻', { item: t(game === 'roblox' ? 'Robux' : 'diamantes') })}
      </div>

      {/* Top Navigation */}
      <Header
        onOpenTracker={() => setIsTrackerOpen(true)}
        onScrollToRecharge={scrollToRecharge}
      />

      {/* Main Content */}
      <main className="flex-1">
        {/* Hero Banner & Value Props */}
        <Hero onScrollToRecharge={scrollToRecharge} game={game} />

        <StatsStrip />

        {/* Recharge Workflow Container */}
        <section
          ref={rechargeSectionRef}
          id="recargar"
          className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-16 space-y-8"
        >
          {/* Section Kicker */}
          <div className="text-center max-w-3xl mx-auto space-y-2">
            <div className="inline-flex items-center gap-2 text-xs font-bold text-purple-400 uppercase tracking-widest">
              <Sparkles className="w-4 h-4 text-purple-400" />
              <span>{t("Plataforma Oficial de Recargas")}</span>
            </div>
            <h2 className="font-display text-2xl sm:text-3xl md:text-4xl font-black title-grad tracking-tight">
              {t('Completa tu Recarga en {n} Simples Pasos', { n: game === 'roblox' ? 2 : 3 })}
            </h2>
            <p className="text-sm sm:text-base text-slate-400">
              {game === 'roblox'
                ? t('Entrega inmediata de Robux a tu cuenta de Roblox por usuario en Colombia. Sin contraseñas ni intermediarios.')
                : t('Entrega inmediata a tu cuenta de Free Fire por ID oficial en Colombia. Sin contraseñas ni intermediarios.')}
            </p>
          </div>

          <GameSelector selected={game} onSelect={handleSelectGame} />

          {/* Validation Alert Message if present */}
          {validationAlert && (
            <div className="p-4 rounded-2xl bg-rose-950/70 border border-rose-500/50 flex items-center justify-between text-sm text-rose-200 shadow-lg">
              <div className="flex items-center gap-2.5">
                <AlertCircle className="w-5 h-5 text-rose-400 shrink-0" />
                <span className="font-medium">{validationAlert}</span>
              </div>
              <button
                onClick={() => setValidationAlert(null)}
                className="text-xs font-bold text-rose-300 hover:text-white px-2 py-1 rounded cursor-pointer"
              >
                {t("Entendido")}
              </button>
            </div>
          )}

          {game === 'freefire' && (
          <>
{/* Step 1: Player ID (Direct Pro UID) */}
          <PlayerIdStep
            playerId={playerId}
            game={game}
            onPlayerIdChange={(id) => {
              setPlayerId(id);
              if (validationAlert) setValidationAlert(null);
            }}
          />
          </>
          )}

          {/* Step 2: Diamond Packages (Exact COP prices & amounts) */}
          <PackagesGrid
            game={game}
            selectedPackage={selectedPackage}
            onSelectPackage={(pkg) => {
              setSelectedPackage(pkg);
              if (validationAlert) setValidationAlert(null);
            }}
          />

          {/* Step 3: Payment Method and Phone/Email */}
          <PaymentStep
            selectedPayment={selectedPayment}
            onSelectPayment={(pm) => {
              setSelectedPayment(pm);
              if (validationAlert) setValidationAlert(null);
            }}
            phone={phone}
            onPhoneChange={(val) => {
              setPhone(val);
              if (validationAlert) setValidationAlert(null);
            }}
            email={email}
            onEmailChange={setEmail}
            stepNumber={game === 'roblox' ? 2 : 3}
            canProceed={Boolean((game === 'roblox' || playerId) && selectedPackage && selectedPayment)}
            onProceed={handleOpenProceed}
          />
        </section>

        {/* How It Works Explainer */}
        <HowItWorks game={game} />

        <WhyUs />

        <PaymentsStrip />

        {/* Trust Metrics & FAQ Accordion */}
        <TrustAndFaqSection />

        <FinalCTA onScrollToRecharge={scrollToRecharge} />
      </main>

      {/* Cementerio de Halloween */}
      <div className="relative -mb-px pointer-events-none select-none">
        <Graveyard className="w-full h-20 sm:h-28 block" />
      </div>

      {/* Botón flotante de WhatsApp */}
      <a
        href="https://wa.me/573016886549?text=Hola%20Nuvem%20Store%2C%20quiero%20hacer%20una%20recarga"
        target="_blank"
        rel="noopener noreferrer"
        aria-label="WhatsApp"
        className="fixed bottom-5 right-5 z-40 w-14 h-14 rounded-full flex items-center justify-center text-white bg-gradient-to-b from-emerald-400 to-emerald-600 border border-white/30 shadow-[inset_0_1px_0_rgba(255,255,255,0.5),0_10px_30px_rgba(16,185,129,0.45)] hover:scale-105 transition-transform"
      >
        <MessageCircle className="w-6 h-6" />
      </a>

      {/* Footer */}
      <Footer
        onOpenTracker={() => setIsTrackerOpen(true)}
        onScrollToRecharge={scrollToRecharge}
      />

      {/* Checkout Summary Modal */}
      {selectedPackage && selectedPayment && (
        <CheckoutSummaryModal
          isOpen={isSummaryOpen}
          onClose={() => setIsSummaryOpen(false)}
          playerId={playerId}
          selectedPackage={selectedPackage}
          selectedPayment={selectedPayment}
          phone={phone}
          email={email}
          onConfirmOrder={handleConfirmOrder}
          isSubmitting={isSubmitting}
          game={game}
        />
      )}

      {/* Order Success Voucher Modal */}
      {currentOrder && (
        <OrderSuccessModal
          isOpen={isSuccessOpen}
          onClose={() => setIsSuccessOpen(false)}
          order={currentOrder}
        />
      )}

      {/* Order Tracker Modal */}
      <OrderTrackerModal
        isOpen={isTrackerOpen}
        onClose={() => setIsTrackerOpen(false)}
      />
    </div>
    </>
  );
}
