// Todas las imágenes del sitio por URL. Cambia el link aquí y se actualiza en toda la web.
export const IMAGES = {
  logo: "https://i.ibb.co/cSVybbD6/logonuvem.jpg",
  hero: "https://i.ibb.co/mVcwPfBz/nuvem67.jpg",
  diamond: "https://i.ibb.co/Y7wqb6QS/diamnates.jpg",
  freefireLogo: "https://i.ibb.co/Q3CzSZSM/garena-free-fire-20192221291138-1.jpg",
  robloxLogo: "https://i.ibb.co/twdm3bC2/da6f8b3f-baa1-46f6-a865-6a6a33be912c.jpg",
  robuxIcon: "https://i.ibb.co/mrqfZqkT/logo.webp",
} as const;
