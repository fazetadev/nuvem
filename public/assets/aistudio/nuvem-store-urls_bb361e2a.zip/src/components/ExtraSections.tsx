import React from 'react';
import { Zap, Clock, MessageCircle, ShieldCheck, Wallet, Lock, Globe, BadgeCheck, Sparkles, ArrowRight, Headphones } from 'lucide-react';
import { useI18n } from '../i18n.tsx';

/** Franja de datos clave justo debajo del Hero */
export const StatsStrip: React.FC = () => {
  const { t } = useI18n();
  const items = [
    { icon: <Clock className="w-5 h-5" />, big: '1–3 min', small: 'Entrega promedio' },
    { icon: <Headphones className="w-5 h-5" />, big: '24/7', small: 'Soporte por WhatsApp' },
    { icon: <Lock className="w-5 h-5" />, big: '0', small: 'Contraseñas solicitadas' },
    { icon: <Wallet className="w-5 h-5" />, big: '3', small: 'Métodos de pago' },
  ];
  return (
    <section className="relative -mt-2 pb-4">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
          {items.map((it) => (
            <div key={it.small} className="bg-[#110d21] border rounded-2xl px-4 py-4 sm:px-5 sm:py-5 flex items-center gap-3 sm:gap-4">
              <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-orange-400/30 to-purple-600/30 border border-white/15 flex items-center justify-center text-orange-300 shrink-0 shadow-[inset_0_1px_0_rgba(255,255,255,0.3)]">
                {it.icon}
              </div>
              <div className="min-w-0">
                <div className="font-display text-xl sm:text-2xl font-black text-white leading-none">{it.big}</div>
                <div className="text-[11px] sm:text-xs text-slate-400 mt-1 leading-snug">{t(it.small)}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

/** Por qué elegir Nuvem Store */
export const WhyUs: React.FC = () => {
  const { t } = useI18n();
  const feats = [
    { icon: <Zap className="w-6 h-6" />, title: 'Entrega rápida', desc: 'Recibes tu recarga en minutos una vez confirmado el pago.' },
    { icon: <ShieldCheck className="w-6 h-6" />, title: 'Cuenta 100% segura', desc: 'Nunca pedimos contraseñas ni accesos a tu cuenta de juego.' },
    { icon: <MessageCircle className="w-6 h-6" />, title: 'Soporte humano', desc: 'Te atendemos por WhatsApp para resolver dudas y revisar tu comprobante.' },
    { icon: <BadgeCheck className="w-6 h-6" />, title: 'Precios claros', desc: 'Tarifas fijas, sin comisiones ocultas ni costos sorpresa.' },
    { icon: <Globe className="w-6 h-6" />, title: 'Pesos o dólares', desc: 'Cambia entre COP y USD con un clic, desde Colombia o el exterior.' },
    { icon: <Sparkles className="w-6 h-6" />, title: 'Dos juegos, una tienda', desc: 'Diamantes de Free Fire y Robux de Roblox en el mismo lugar.' },
  ];
  return (
    <section id="beneficios" className="py-14 sm:py-20 border-b border-purple-950/60">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-12 space-y-3">
          <div className="inline-flex items-center gap-2 text-xs font-semibold text-purple-400 uppercase tracking-[0.18em]">
            <span>{t('Por qué elegirnos')}</span>
          </div>
          <h2 className="title-grad font-display text-2xl sm:text-3xl md:text-4xl font-black tracking-tight">
            {t('Una tienda hecha para jugadores')}
          </h2>
          <p className="text-slate-300 text-sm sm:text-base leading-relaxed">
            {t('Rapidez, seguridad y atención real en cada recarga.')}
          </p>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {feats.map((f) => (
            <div key={f.title} className="bg-[#110d21] border rounded-3xl p-6 group transition-transform duration-300 hover:-translate-y-1">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-orange-400/30 to-purple-600/30 border border-white/15 flex items-center justify-center text-orange-300 mb-4 shadow-[inset_0_1px_0_rgba(255,255,255,0.3)] group-hover:scale-105 transition-transform">
                {f.icon}
              </div>
              <h3 className="font-display text-lg font-bold text-white mb-1.5">{t(f.title)}</h3>
              <p className="text-sm text-slate-400 leading-relaxed">{t(f.desc)}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

/** Franja de métodos de pago */
export const PaymentsStrip: React.FC = () => {
  const { t } = useI18n();
  const methods = ['Nequi', 'Bancolombia', 'PayPal'];
  return (
    <section className="py-10">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-[#110d21] border rounded-3xl px-6 py-6 sm:px-8 flex flex-col sm:flex-row items-center justify-between gap-5">
          <div className="text-center sm:text-left">
            <div className="font-display text-lg font-bold text-white">{t('Paga como prefieras')}</div>
            <div className="text-xs sm:text-sm text-slate-400">{t('Métodos locales e internacionales, con tus datos de pago por WhatsApp.')}</div>
          </div>
          <div className="flex flex-wrap items-center justify-center gap-2.5">
            {methods.map((m) => (
              <span key={m} className="px-4 py-2 rounded-full text-sm font-bold text-white bg-white/5 border border-white/15 shadow-[inset_0_1px_0_rgba(255,255,255,0.2)]">
                {m}
              </span>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

/** Llamado final a la acción */
export const FinalCTA: React.FC<{ onScrollToRecharge: () => void }> = ({ onScrollToRecharge }) => {
  const { t } = useI18n();
  return (
    <section className="py-14 sm:py-20">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="relative overflow-hidden rounded-[2rem] p-8 sm:p-12 text-center border border-white/20 bg-gradient-to-br from-orange-500/25 via-purple-700/25 to-purple-950/40 backdrop-blur-xl shadow-[inset_0_1px_0_rgba(255,255,255,0.35),0_20px_60px_rgba(0,0,0,0.5)]">
          <div className="absolute -top-24 -right-24 w-72 h-72 rounded-full bg-orange-500/25 blur-3xl pointer-events-none" />
          <div className="absolute -bottom-24 -left-24 w-72 h-72 rounded-full bg-purple-600/30 blur-3xl pointer-events-none" />
          <div className="relative space-y-4">
            <h2 className="font-display text-2xl sm:text-4xl font-black text-white tracking-tight">
              {t('¿Listo para tu próxima recarga?')}
            </h2>
            <p className="text-slate-200/90 text-sm sm:text-base max-w-xl mx-auto">
              {t('Elige tu juego, escoge tu paquete y recibe tu recarga en minutos.')}
            </p>
            <button
              onClick={onScrollToRecharge}
              className="mt-2 inline-flex items-center gap-2 px-8 py-3.5 text-sm font-bold text-white bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 rounded-xl transition-all duration-200 hover:-translate-y-0.5 cursor-pointer"
            >
              <span>{t('Recargar Ahora')}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};
