import { useI18n } from '../i18n.tsx';
import { IMAGES } from "../config/images";
import { Pumpkin, Cobweb, Ghost, Bat } from './HalloweenDecor.tsx';
import React from 'react';
import { Zap, ShieldCheck, Clock, CheckCircle2, Flame, ArrowDown } from 'lucide-react';

interface HeroProps {
  onScrollToRecharge: () => void;
  game?: 'freefire' | 'roblox';
}

export const Hero: React.FC<HeroProps> = ({ onScrollToRecharge, game = 'freefire' }) => {
  const { t } = useI18n();
  const isRoblox = game === 'roblox';
  const headParts = t(
    isRoblox
      ? 'Compra tus Robux de {game} al Mejor Precio en Colombia'
      : 'Recarga tus Diamantes de {game} al Mejor Precio en Colombia'
  ).split('{game}');
  const descParts = t(
    isRoblox
      ? 'En {brand} recibes tus Robux directo en tu cuenta en menos de 2 minutos. Paga fácil con Nequi, Bancolombia o PayPal, sin comisiones ocultas.'
      : 'En {brand} recibes tus diamantes oficiales directo en tu cuenta en menos de 2 minutos. Paga fácil con Nequi, Bancolombia o PayPal, sin comisiones ocultas.'
  ).split('{brand}');
  return (
    <section className="relative overflow-hidden pt-8 pb-12 sm:pt-12 sm:pb-16 border-b border-purple-950/40">
      {/* Background ambient purple light glows */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-7xl h-96 bg-purple-600/10 blur-[130px] pointer-events-none rounded-full" />
      <div className="absolute top-20 right-10 w-72 h-72 bg-indigo-600/10 blur-[100px] pointer-events-none rounded-full" />

      <Cobweb className="absolute top-0 left-0 w-28 sm:w-44 text-orange-200/25 pointer-events-none" />
      <Cobweb className="absolute top-0 right-0 w-28 sm:w-44 text-orange-200/25 pointer-events-none -scale-x-100" />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14 items-center">
          
          {/* Left Column: Headlines & Call to Action */}
          <div className="lg:col-span-7 space-y-6 text-center flex flex-col items-center">
            
            {/* Trust Kicker (Clean unboxed text, no pills) */}
            <div className="flex flex-wrap items-center justify-center gap-x-2 gap-y-1 text-xs font-semibold text-purple-400">
              <span className="flex items-center gap-1.5 text-purple-300">
                <Flame className="w-3.5 h-3.5 text-purple-400" />
                {t('Entrega Inmediata 24/7')}
              </span>
              <span aria-hidden="true" className="text-purple-700">·</span>
              <span className="text-slate-300">{isRoblox ? t('Solo con tu usuario') : t('Solo con tu UID')}</span>
              <span aria-hidden="true" className="text-purple-700">·</span>
              <span className="text-slate-300">{isRoblox ? t('100% Seguro, sin contraseñas') : t('100% Anti-Ban Garena')}</span>
            </div>

            {/* Main Headline (Refined font weight & tracking) */}
            <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-[54px] font-extrabold text-white tracking-tight leading-[1.1] text-balance">
              {headParts[0]}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-400 via-purple-300 to-indigo-300">
                {isRoblox ? 'Roblox' : 'Free Fire'}
              </span>
              {headParts[1]}
            </h1>

            <p className="text-slate-300 text-sm sm:text-base max-w-xl mx-auto leading-relaxed font-normal">
              {descParts[0]}<strong className="text-white font-semibold">{t("Nuvem Store")}</strong>{descParts[1]}
            </p>

            {/* CTAs */}
            <div className="flex flex-col sm:flex-row items-center justify-center gap-3.5 pt-2">
              <button
                onClick={onScrollToRecharge}
                className="w-full sm:w-auto px-8 py-3.5 text-sm font-bold text-white bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 rounded-xl shadow-lg shadow-purple-900/40 hover:shadow-purple-700/50 transition-all duration-200 transform hover:-translate-y-0.5 flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>{t("Comenzar Recarga")}</span>
                <ArrowDown className="w-4 h-4 text-purple-200 animate-bounce" />
              </button>

              <a
                href="#como-funciona"
                className="w-full sm:w-auto px-5 py-3.5 text-xs sm:text-sm font-semibold text-purple-200 hover:text-white bg-purple-950/30 hover:bg-purple-900/40 border border-purple-800/40 rounded-xl transition-colors flex items-center justify-center gap-2"
              >
                <span>{t("Ver Paso a Paso")}</span>
              </a>
            </div>

            {/* Security points */}
            <div className="w-full flex flex-wrap justify-center gap-x-8 gap-y-3 pt-4 border-t border-purple-900/30">
              <div className="flex items-center gap-2">
                <Zap className="w-4 h-4 text-purple-400 shrink-0" />
                <span className="text-xs text-slate-300 font-medium">{t("Acreditación Rápida")}</span>
              </div>
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-purple-400 shrink-0" />
                <span className="text-xs text-slate-300 font-medium">{t("Sin Contraseñas")}</span>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-purple-400 shrink-0" />
                <span className="text-xs text-slate-300 font-medium">{t("Soporte 24/7")}</span>
              </div>
            </div>

          </div>

          {/* Right Column: Visual Showcase Card */}
          <div className="lg:col-span-5 relative w-full max-w-xl mx-auto lg:max-w-none animate-[floaty_6s_ease-in-out_infinite]">
            <Pumpkin className="hw-pumpkin absolute -bottom-7 -left-5 sm:-left-8 w-20 sm:w-24 z-20" />
            <Pumpkin className="hw-pumpkin absolute -bottom-5 -right-3 sm:-right-5 w-14 sm:w-16 z-20" style={{ animationDelay: '1.2s' }} />
            <Ghost className="hw-ghost absolute -top-8 -right-2 sm:-right-6 w-12 sm:w-14 z-20 opacity-90" />
            <Bat className="absolute -top-5 left-4 w-10 text-[#0a0710] z-20 hw-bat-flap" />
            <div className="relative rounded-3xl p-1.5 bg-gradient-to-b from-purple-500/20 via-purple-900/10 to-transparent border border-purple-500/25 shadow-2xl shadow-purple-950/80">
              
              {/* Main Banner Image */}
              <div className="relative rounded-2xl overflow-hidden aspect-[4/3] sm:aspect-[16/10] bg-[#120f1e]">
                <img decoding="async"
                  src={IMAGES.hero}
                  fetchPriority="high"
                  alt={`Nuvem Store ${isRoblox ? 'Roblox' : 'Free Fire'}`}
                  className="w-full h-full object-cover object-center"
                  referrerPolicy="no-referrer"
                />
                
                {/* Gradient Scrim for Legibility */}
                <div className="absolute inset-0 bg-gradient-to-t from-[#0b0a12] via-transparent to-black/20" />

                {/* Bottom Card Overlay Bar */}
                <div className="absolute bottom-3 left-3 right-3 p-3 bg-[#0e0a1a]/95 backdrop-blur-md rounded-xl border border-purple-800/40 flex items-center justify-between">
                  <div>
                    <span className="text-[10px] text-purple-300/80 font-medium block">
                      {t("Entrega Oficial Colombia")}
                    </span>
                    <span className="text-xs sm:text-sm font-bold text-white">
                      {t("Acreditación Directa por UID")}
                    </span>
                  </div>
                  <div className="flex items-center gap-1.5 text-xs font-semibold text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded-lg border border-emerald-500/30">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>{t("Garantizado")}</span>
                  </div>
                </div>

              </div>

            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
