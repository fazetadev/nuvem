import { useI18n } from '../i18n.tsx';
import React from 'react';
import { GAME_INFO } from '../utils/rechargeLogic.ts';
import type { GameId } from '../types/store.ts';
import { User, Gem, CreditCard, Sparkles, CheckCircle2 } from 'lucide-react';

export const HowItWorks: React.FC<{ game?: GameId }> = ({ game = 'freefire' }) => {
  const { t, formatPrice } = useI18n();
  const info = GAME_INFO[game];
  const isRoblox = game === 'roblox';
  const steps = [
    {
      step: '01',
      title: isRoblox ? t('Ingresa tu Usuario') : t('Ingresa tu UID'),
      desc: isRoblox
        ? t('Escribe tu nombre de usuario de Roblox. No requerimos contraseña ni datos de acceso a tu cuenta.')
        : t('Escribe tu ID de jugador de Free Fire. No requerimos contraseña ni datos de acceso a tu cuenta.'),
      icon: <User className="w-6 h-6 text-purple-400" />,
    },
    {
      step: '02',
      title: t('Elige tus {item}', { item: t(info.unit) }),
      desc: t('Selecciona desde {from} hasta {to} con las mejores tarifas.', isRoblox
        ? { from: `100 Robux (${formatPrice(4000)})`, to: `1.000 Robux (${formatPrice(45000)})` }
        : { from: `100 ${t('diamantes')} (${formatPrice(3200, 1.03)})`, to: `5.600 ${t('diamantes')} (${formatPrice(160000, 37.99)})` }),
      icon: <Gem className="w-6 h-6 text-purple-400" />,
    },
    {
      step: '03',
      title: t('Paga con Nequi, Bancolombia o PayPal'),
      desc: t('Transfiere fácil y al instante desde tu aplicación o punto de pago preferido sin comisiones extras.'),
      icon: <CreditCard className="w-6 h-6 text-purple-400" />,
    },
    {
      step: '04',
      title: t('Acreditación Inmediata'),
      desc: isRoblox
        ? t('En 1 a 3 minutos abre Roblox y disfruta de tus Robux para avatares, pases y experiencias.')
        : t('En 1 a 3 minutos abre tu Free Fire y disfruta de tus diamantes oficiales para pases, ruletas y skins.'),
      icon: <Sparkles className="w-6 h-6 text-purple-400" />,
    },
  ].filter((st) => !(isRoblox && st.step === '01')).map((st, i) => ({ ...st, step: String(i + 1).padStart(2, '0') }));

  return (
    <section id="como-funciona" className="py-12 sm:py-16 border-b border-purple-950/60">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-12 space-y-3">
          <div className="inline-flex items-center gap-2 text-xs font-semibold text-purple-400 uppercase tracking-wider">
            <span>{t("Proceso Simple y 100% Confiable")}</span>
          </div>
          <h2 className="font-display text-2xl sm:text-3xl md:text-4xl font-black title-grad tracking-tight">
            {t("¿Cómo Funciona Nuvem Store?")}
          </h2>
          <p className="text-slate-300 text-sm sm:text-base leading-relaxed">
            {t('Recargar {item} nunca había sido tan fácil, rápido y seguro para jugadores en Colombia.', { item: t(info.unitLower) })}
          </p>
        </div>

        {/* Steps Grid */}
        <div className={`grid grid-cols-1 sm:grid-cols-2 gap-6 ${isRoblox ? 'lg:grid-cols-3' : 'lg:grid-cols-4'}`}>
          {steps.map((st) => (
            <div
              key={st.step}
              className="p-6 rounded-2xl bg-[#100c1e] border border-purple-900/40 hover:border-purple-600/50 transition-all group flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-5">
                  <div className="w-12 h-12 rounded-xl bg-purple-950/80 border border-purple-700/40 flex items-center justify-center group-hover:scale-105 transition-transform">
                    {st.icon}
                  </div>
                  <span className="font-mono text-2xl font-black text-purple-500/40 group-hover:text-purple-400/80 transition-colors">
                    {st.step}
                  </span>
                </div>

                <h3 className="font-display text-lg font-bold text-white mb-2 tracking-tight">
                  {st.title}
                </h3>

                <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
                  {st.desc}
                </p>
              </div>

              <div className="mt-5 pt-3 border-t border-purple-950 flex items-center gap-1.5 text-[11px] text-purple-300/80 font-medium">
                <CheckCircle2 className="w-3.5 h-3.5 text-purple-400" />
                <span>{t("Paso Verificado")}</span>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
