import React from 'react';
import { useI18n } from '../i18n.tsx';
import { IMAGES } from '../config/images';
import type { GameId } from '../types/store.ts';
export type { GameId };

const GAMES: { id: GameId; name: string; logo: string }[] = [
  { id: 'freefire', name: 'Free Fire', logo: IMAGES.freefireLogo },
  { id: 'roblox', name: 'Roblox', logo: IMAGES.robloxLogo },
];

interface Props {
  selected: GameId;
  onSelect: (g: GameId) => void;
}

export const GameSelector: React.FC<Props> = ({ selected, onSelect }) => {
  const { t } = useI18n();
  return (
  <div className="w-fit mx-auto rounded-2xl px-4 py-3 bg-[#120f1e]/90 border border-purple-800/40">
    <h3 className="text-[11px] font-bold text-purple-300 uppercase tracking-wider text-center mb-2.5">
      {t("Selección de Juego")}
    </h3>
    <div className="flex items-center justify-center gap-2.5">
      {GAMES.map((g) => {
        const active = selected === g.id;
        return (
          <button
            key={g.id}
            type="button"
            onClick={() => onSelect(g.id)}
            aria-pressed={active}
            className={`flex items-center gap-2 pl-1.5 pr-3.5 py-1.5 rounded-xl border transition-all cursor-pointer outline-none ${
              active
                ? 'bg-purple-900/40 border-purple-400 shadow-md shadow-purple-700/30'
                : 'bg-[#0d0a17] border-purple-900/50 opacity-70 hover:opacity-100 hover:border-purple-600'
            }`}
          >
            <img decoding="async" src={g.logo} alt={g.name} className="w-8 h-8 rounded-lg object-cover" referrerPolicy="no-referrer" />
            <span className={`text-xs font-bold ${active ? 'text-white' : 'text-slate-300'}`}>{g.name}</span>
          </button>
        );
      })}
    </div>
  </div>
  );
};
