import { useI18n } from '../i18n.tsx';
import React from 'react';
import { CreditCard, Smartphone, Wallet, Building2, Banknote, ShieldCheck, ArrowRight, Check } from 'lucide-react';
import { PaymentMethod } from '../types/store.ts';
import { PAYMENT_METHODS } from '../utils/rechargeLogic.ts';

interface PaymentStepProps {
  selectedPayment: PaymentMethod | null;
  onSelectPayment: (method: PaymentMethod) => void;
  phone: string;
  onPhoneChange: (val: string) => void;
  email: string;
  onEmailChange: (val: string) => void;
  canProceed: boolean;
  stepNumber?: number;
  onProceed: () => void;
}

export const PaymentStep: React.FC<PaymentStepProps> = ({
  selectedPayment,
  onSelectPayment,
  phone,
  onPhoneChange,
  email,
  onEmailChange,
  canProceed,
  stepNumber = 3,
  onProceed,
}) => {
  const { t } = useI18n();
  const getMethodIcon = (iconName: string) => {
    switch (iconName) {
      case 'Smartphone':
        return <Smartphone className="w-4 h-4" />;
      case 'Wallet':
        return <Wallet className="w-4 h-4" />;
      case 'Building2':
        return <Building2 className="w-4 h-4" />;
      case 'CreditCard':
        return <CreditCard className="w-4 h-4" />;
      default:
        return <Banknote className="w-4 h-4" />;
    }
  };

  return (
    <div id="metodos-pago" className="p-5 sm:p-7 rounded-3xl bg-[#120f1e]/90 border border-purple-900/40 backdrop-blur-md shadow-xl shadow-purple-950/20 space-y-5">
      
      {/* Step Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-purple-900/30">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-xl bg-purple-600/30 border border-purple-500/40 flex items-center justify-center text-purple-300 font-bold font-mono text-sm">
            {stepNumber}
          </div>
          <div>
            <h2 className="text-lg sm:text-xl font-bold text-white tracking-tight">
              {t("Medio de Pago en Colombia")}
            </h2>
            <p className="text-xs text-purple-300/80">
              {t("Pagos instantáneos y 100% seguros sin comisiones extras")}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-1.5 text-xs text-purple-300 font-medium">
          <ShieldCheck className="w-4 h-4 text-purple-400" />
          <span>{t("Verificación Inmediata")}</span>
        </div>
      </div>

      {/* Payment Methods Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        {PAYMENT_METHODS.map((method) => {
          const isSelected = selectedPayment?.id === method.id;

          return (
            <div
              key={method.id}
              role="button"
              tabIndex={0}
              onClick={() => onSelectPayment(method)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                  e.preventDefault();
                  onSelectPayment(method);
                }
              }}
              className={`p-3.5 rounded-xl text-left transition-all duration-150 cursor-pointer flex flex-col justify-between group ${
                isSelected
                  ? 'bg-gradient-to-b from-purple-900/60 via-[#1b1430] to-[#120d22] border-2 border-purple-400 shadow-md shadow-purple-900/40 ring-1 ring-purple-400/40'
                  : 'bg-[#0d0a17] hover:bg-[#151024] border border-purple-900/50 hover:border-purple-600/60'
              }`}
            >
              <div className="flex items-center justify-between gap-2.5">
                <div className="flex items-center gap-2.5">
                  <div
                    className={`w-9 h-9 rounded-lg flex items-center justify-center transition-all ${
                      isSelected
                        ? 'bg-purple-600 text-white shadow-sm'
                        : 'bg-purple-950/60 text-purple-300 border border-purple-800/40'
                    }`}
                  >
                    {getMethodIcon(method.iconName)}
                  </div>
                  <div>
                    <span className="font-bold text-white text-xs sm:text-sm block">
                      {method.name}
                    </span>
                    <span className="text-[10px] text-slate-400 block line-clamp-1">
                      {t(method.shortDesc)}
                    </span>
                  </div>
                </div>

                <div
                  className={`w-4 h-4 rounded-full flex items-center justify-center border transition-all ${
                    isSelected
                      ? 'bg-purple-500 border-purple-400 text-white'
                      : 'border-purple-800/60 group-hover:border-purple-500'
                  }`}
                >
                  {isSelected && <Check className="w-2.5 h-2.5 stroke-[3]" />}
                </div>
              </div>

              {method.badge && (
                <div className="mt-2.5">
                  <span className="inline-block text-[9px] font-bold uppercase tracking-wider text-purple-300 bg-purple-950/80 border border-purple-800/40 px-2 py-0.5 rounded-md">
                    {t(method.badge)}
                  </span>
                </div>
              )}
            </div>
          );
        })}
      </div>

      <p className="flex items-center gap-2 text-[11px] sm:text-xs text-slate-400">
        <ShieldCheck className="w-4 h-4 text-purple-400 shrink-0" />
        {t('Al confirmar tu pedido te enviamos los datos de pago por WhatsApp.')}
      </p>

      {/* Contact Details & Final Trigger */}
      <div className="pt-5 border-t border-purple-900/30 grid grid-cols-1 md:grid-cols-12 gap-4 items-end">
        
        {/* WhatsApp / Phone field */}
        <div className="md:col-span-4 space-y-1.5">
          <label htmlFor="customer-phone" className="block text-xs font-bold text-slate-300 uppercase tracking-wider">
            {t("Tu WhatsApp / Celular")} <span className="text-purple-400">*</span>
          </label>
          <input
            id="customer-phone"
            type="tel"
            placeholder={t("Ej: 310 123 4567")}
            value={phone}
            onChange={(e) => onPhoneChange(e.target.value)}
            className="w-full h-11 px-3.5 rounded-xl bg-[#090810] border border-purple-900/60 focus:border-purple-500 focus:ring-2 focus:ring-purple-500/20 text-white placeholder-slate-500 text-xs sm:text-sm font-medium outline-none"
          />
          <span className="text-[10px] text-slate-400 block">
            {t("Para enviarte el recibo y comprobante de recarga")}
          </span>
        </div>

        {/* Email field */}
        <div className="md:col-span-4 space-y-1.5">
          <label htmlFor="customer-email" className="block text-xs font-bold text-slate-300 uppercase tracking-wider">
            {t("Correo Electrónico (Opcional)")}
          </label>
          <input
            id="customer-email"
            type="email"
            placeholder={t("tucorreo@ejemplo.com")}
            value={email}
            onChange={(e) => onEmailChange(e.target.value)}
            className="w-full h-11 px-3.5 rounded-xl bg-[#090810] border border-purple-900/60 focus:border-purple-500 focus:ring-2 focus:ring-purple-500/20 text-white placeholder-slate-500 text-xs sm:text-sm font-medium outline-none"
          />
          <span className="text-[10px] text-slate-400 block">
            {t("Copia de respaldo del pedido")}
          </span>
        </div>

        {/* Primary Action Button */}
        <div className="md:col-span-4">
          <button
            type="button"
            onClick={onProceed}
            disabled={!canProceed}
            className="w-full h-11 px-6 text-xs sm:text-sm font-bold text-white bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 rounded-xl shadow-lg shadow-purple-900/40 hover:shadow-purple-700/50 disabled:opacity-40 disabled:cursor-not-allowed transition-all duration-150 flex items-center justify-center gap-2 cursor-pointer"
          >
            <span>{t("Confirmar Recarga")}</span>
            <ArrowRight className="w-4 h-4 text-purple-200" />
          </button>
        </div>

      </div>

    </div>
  );
};
