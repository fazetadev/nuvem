import { useI18n } from '../i18n.tsx';
import React from 'react';
import { MessageCircle, ShieldCheck, Heart } from 'lucide-react';

interface FooterProps {
  onOpenTracker: () => void;
  onScrollToRecharge: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenTracker, onScrollToRecharge }) => {
  const { t } = useI18n();
  return (
    <footer className="bg-[#08070e] border-t border-purple-950/80 text-slate-400 text-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 pb-10 border-b border-purple-950">
          
          {/* Brand info */}
          <div className="md:col-span-5 space-y-3">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-purple-600 flex items-center justify-center text-white font-black font-display text-sm">
                {t("N")}
              </div>
              <span className="font-display text-lg font-black text-white uppercase tracking-tight">
                {t("nuvem")} <span className="text-purple-400">{t("store")}</span>
              </span>
            </div>
            <p className="text-slate-400 text-xs max-w-sm leading-relaxed">
              {t("Tu tienda de confianza para recargas de diamantes de Free Fire y Robux de Roblox en Colombia. Precios justos en COP, sin intermediarios riesgosos y entrega directa.")}
            </p>
            <div className="flex items-center gap-2 text-purple-300 font-medium">
              <ShieldCheck className="w-4 h-4 text-purple-400" />
              <span>{t("Plataforma 100% Segura & Anti-Ban")}</span>
            </div>
          </div>

          {/* Quick Links */}
          <div className="md:col-span-3 space-y-2.5">
            <h4 className="text-white font-bold text-sm tracking-tight font-display">
              {t("Navegación Rápida")}
            </h4>
            <ul className="space-y-2">
              <li>
                <button
                  onClick={onScrollToRecharge}
                  className="hover:text-purple-300 transition-colors cursor-pointer text-left"
                >
                  {t("Paquetes de Recarga")}
                </button>
              </li>
              <li>
                <a href="#como-funciona" className="hover:text-purple-300 transition-colors">
                  {t("¿Cómo Funciona?")}
                </a>
              </li>
              <li>
                <button
                  onClick={onOpenTracker}
                  className="hover:text-purple-300 transition-colors cursor-pointer text-left"
                >
                  {t("Consultar Estado de Pedido")}
                </button>
              </li>
              <li>
                <a href="#faq" className="hover:text-purple-300 transition-colors">
                  {t("Preguntas Frecuentes")}
                </a>
              </li>
            </ul>
          </div>

          {/* Colombian Payment and WhatsApp Support */}
          <div className="md:col-span-4 space-y-3">
            <h4 className="text-white font-bold text-sm tracking-tight font-display">
              {t("Atención y Soporte")}
            </h4>
            <p className="text-xs text-slate-400">
              {t("¿Dudas con tu pago o acreditación? Escríbenos directamente:")}
            </p>
            <a
              href="https://wa.me/573016886549?text=Hola%20Nuvem%20Store%2C%20necesito%20ayuda%20con%20una%20recarga%20de%20Free%20Fire"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-emerald-950/60 border border-emerald-500/40 text-emerald-300 hover:bg-emerald-900/60 font-bold transition-colors"
            >
              <MessageCircle className="w-4 h-4" />
              <span>{t("WhatsApp: +57 301 688 6549")}</span>
            </a>

            <div className="pt-2">
              <span className="text-[11px] text-slate-500 block mb-1">{t("Métodos habilitados en Colombia:")}</span>
              <div className="flex flex-wrap gap-1.5 text-[10px] text-slate-300 font-medium">
                <span className="px-2 py-0.5 rounded bg-[#130f24] border border-purple-900/40">{t("Nequi")}</span>
                <span className="px-2 py-0.5 rounded bg-[#130f24] border border-purple-900/40">{t("Bancolombia")}</span>
                <span className="px-2 py-0.5 rounded bg-[#130f24] border border-purple-900/40">{t("PayPal")}</span>
              </div>
            </div>
          </div>

        </div>

        {/* Bottom Disclaimer */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-slate-500 text-[11px]">
          <p>© {new Date().getFullYear()} Nuvem Store Colombia. Todos los derechos reservados.</p>
          <p className="text-center sm:text-right">
            {t("Free Fire es una marca registrada de Garena International y Roblox de Roblox Corporation. Nuvem Store es un servicio de recargas independiente.")}
          </p>
        </div>
      </div>
    </footer>
  );
};
