import { useI18n } from '../i18n.tsx';
import React, { useState } from 'react';
import { HelpCircle, CheckCircle2, Clipboard, X, Sparkles, ShieldCheck } from 'lucide-react';
import { validateAccount, GAME_INFO } from '../utils/rechargeLogic.ts';
import type { GameId } from '../types/store.ts';

interface PlayerIdStepProps {
  playerId: string;
  onPlayerIdChange: (id: string) => void;
  game: GameId;
}

export const PlayerIdStep: React.FC<PlayerIdStepProps> = ({
  playerId,
  onPlayerIdChange,
  game,
}) => {
  const { t } = useI18n();
  const info = GAME_INFO[game];
  const isRoblox = game === 'roblox';
  const [showGuide, setShowGuide] = useState(false);
  const [pasteNotice, setPasteNotice] = useState(false);

  const validation = validateAccount(game, playerId);
  const isComplete = validation.isValid;

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = isRoblox
      ? e.target.value.replace(/[^A-Za-z0-9_]/g, '').slice(0, 20)
      : e.target.value.replace(/\D/g, '').slice(0, 12);
    onPlayerIdChange(val);
  };

  const handleClear = () => {
    onPlayerIdChange('');
  };

  const handlePaste = async () => {
    try {
      const text = await navigator.clipboard.readText();
      const numbers = isRoblox
        ? text.trim().replace(/[^A-Za-z0-9_]/g, '').slice(0, 20)
        : text.replace(/\D/g, '').slice(0, 12);
      if (numbers) {
        onPlayerIdChange(numbers);
        setPasteNotice(true);
        setTimeout(() => setPasteNotice(false), 2000);
      }
    } catch {
      // Fallback if clipboard permissions restricted
    }
  };

  return (
    <div className="p-5 sm:p-7 rounded-3xl bg-[#120f1e]/90 border border-purple-900/40 backdrop-blur-md shadow-xl shadow-purple-950/20 space-y-5">
      
      {/* Step Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-purple-900/30">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-xl bg-purple-600/30 border border-purple-500/40 flex items-center justify-center text-purple-300 font-bold font-mono text-sm">
            1
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-lg sm:text-xl font-bold text-white tracking-tight">
                {t(info.stepTitle)}
              </h2>
              <span className="hidden sm:inline-block text-[10px] font-bold text-emerald-400 bg-emerald-950/70 border border-emerald-500/30 px-2 py-0.5 rounded-full">
                {t("100% Automático")}
              </span>
            </div>
            <p className="text-xs text-purple-300/80">
              {t(info.stepSub)}
            </p>
          </div>
        </div>

        {/* How to find ID button */}
        <button
          type="button"
          onClick={() => setShowGuide(!showGuide)}
          className="inline-flex items-center gap-1.5 text-xs font-semibold text-purple-400 hover:text-purple-300 transition-colors cursor-pointer self-start sm:self-auto py-1 px-2 rounded-lg hover:bg-purple-950/50"
        >
          <HelpCircle className="w-4 h-4" />
          <span>{showGuide ? t('Ocultar guía') : isRoblox ? t('¿Dónde veo mi usuario?') : t('¿Dónde encuentro mi ID?')}</span>
        </button>
      </div>

      {/* Guide expander */}
      {showGuide && (
        <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-br from-purple-950/60 via-[#18112e] to-[#0f0c1b] border border-purple-700/40 text-xs text-slate-300 space-y-3 animate-in fade-in duration-200">
          <div className="flex items-center gap-2 text-white font-bold text-sm">
            <Sparkles className="w-4 h-4 text-purple-400" />
            <span>{isRoblox ? t('¿Cómo encontrar tu usuario en Roblox?') : t('¿Cómo encontrar tu ID en Free Fire?')}</span>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
            {(isRoblox
              ? [
                  ['PASO 1', 'Abre Roblox e inicia sesión en tu cuenta.'],
                  ['PASO 2', 'Entra a tu Perfil: tu usuario aparece debajo de tu nombre, con el @.'],
                  ['PASO 3', 'Escríbelo aquí exactamente igual, sin el @ y sin espacios.'],
                ]
              : [
                  ['PASO 1', 'Abre Free Fire y toca tu Perfil / Avatar en la esquina superior izquierda.'],
                  ['PASO 2', 'En la pestaña Básica, localiza tu UID debajo de tu nombre.'],
                  ['PASO 3', 'Toca el botón Copiar al lado del número y pégalo aquí.'],
                ]
            ).map(([label, desc]) => (
              <div key={label} className="p-3 rounded-xl bg-[#0a0714] border border-purple-900/50 space-y-1">
                <span className="font-mono text-purple-400 font-bold block text-[11px]">{t(label)}</span>
                <p className="text-slate-300 text-xs">{t(desc)}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Main Pro Input Form */}
      <div className="space-y-3">
        <label htmlFor="player-id-input" className="block text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center justify-between">
          <span>{t(info.accountField)} *</span>
          <span className="text-[11px] text-purple-400/90 font-mono normal-case">
            {isRoblox
              ? (playerId ? t('{n} caracteres', { n: playerId.length }) : t('3 a 20 caracteres'))
              : (playerId ? t('{n} dígitos', { n: playerId.length }) : t('8 a 12 dígitos numéricos'))}
          </span>
        </label>

        <div className="flex gap-2.5 items-stretch">
          <div className="relative flex-1">
            <input
              id="player-id-input"
              type="text"
              inputMode={isRoblox ? 'text' : 'numeric'}
              autoCapitalize="none"
              autoCorrect="off"
              placeholder={t(info.placeholder)}
              value={playerId}
              onChange={handleInputChange}
              className={`w-full h-12 sm:h-13 pl-4 ${playerId ? 'pr-10' : 'pr-4'} rounded-xl bg-[#090810] border text-white placeholder-slate-500 font-mono text-sm sm:text-base tracking-wider transition-all outline-none ${
                isComplete
                  ? 'border-emerald-500/70 focus:border-emerald-400 focus:ring-2 focus:ring-emerald-500/20'
                  : 'border-purple-900/70 focus:border-purple-500 focus:ring-2 focus:ring-purple-500/20'
              }`}
            />

            {playerId && (
              <button
                type="button"
                onClick={handleClear}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-purple-950/60 transition-colors"
                title={t("Borrar ID")}
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          <button
            type="button"
            onClick={handlePaste}
            className="h-12 sm:h-13 px-4 text-xs font-bold text-purple-200 bg-purple-900/60 hover:bg-purple-800/80 border border-purple-700/50 rounded-xl transition-all flex items-center justify-center gap-1.5 shrink-0 cursor-pointer shadow-sm active:scale-95"
            title={t("Pegar ID desde portapapeles")}
          >
            <Clipboard className="w-4 h-4 text-purple-300" />
            <span>{pasteNotice ? t('¡Listo!') : t('Pegar')}</span>
          </button>
        </div>

        {/* Real-time Status feedback */}
        <div className="flex items-center justify-between text-xs pt-1">
          {isComplete ? (
            <div className="flex items-center gap-1.5 text-emerald-400 font-medium animate-in fade-in">
              <CheckCircle2 className="w-4 h-4" />
              <span>{isRoblox ? t('Usuario válido para entrega inmediata en Colombia') : t('Formato de ID válido para recarga inmediata en Colombia')}</span>
            </div>
          ) : playerId ? (
            <span className="text-amber-400/90">
              {isRoblox ? t('Usa 3 a 20 caracteres (llevas {n})', { n: playerId.length }) : t('Ingresa entre 8 y 12 dígitos (llevas {n})', { n: playerId.length })}
            </span>
          ) : (
            <span className="text-slate-500">
              {t(info.hint)}
            </span>
          )}

          <div className="hidden sm:flex items-center gap-1.5 text-slate-400 text-[11px]">
            <ShieldCheck className="w-3.5 h-3.5 text-purple-400" />
            <span>{t("Acreditación 100% Segura")}</span>
          </div>
        </div>

      </div>

    </div>
  );
};
