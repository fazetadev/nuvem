import React, { useEffect, useRef } from 'react';

// Fondo animado ligero: estrellas moradas/naranjas que titilan + estrellas fugaces.
// Optimizado para móvil: sprites pre-renderizados, DPR 1, 30 fps de dibujo en móvil
// y ajuste automático de calidad si el equipo no llega a 60 fps.
interface Star { x: number; y: number; r: number; phase: number; speed: number; sprite: number; cross: boolean; }
interface Meteor { x: number; y: number; vx: number; vy: number; len: number; w: number; life: number; max: number; hue: number; }

const HUES = [28, 36, 44, 262, 275, 285];

function makeSprite(hue: number): HTMLCanvasElement {
  const size = 32;
  const c = document.createElement('canvas');
  c.width = c.height = size;
  const g = c.getContext('2d')!;
  const grad = g.createRadialGradient(size / 2, size / 2, 0, size / 2, size / 2, size / 2);
  grad.addColorStop(0, `hsla(${hue},100%,92%,1)`);
  grad.addColorStop(0.18, `hsla(${hue},95%,75%,0.9)`);
  grad.addColorStop(0.5, `hsla(${hue},90%,60%,0.25)`);
  grad.addColorStop(1, `hsla(${hue},90%,60%,0)`);
  g.fillStyle = grad;
  g.fillRect(0, 0, size, size);
  return c;
}

export const StarParticles: React.FC = () => {
  const ref = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d', { alpha: true });
    if (!ctx) return;

    const isMobile = window.matchMedia?.('(max-width: 1024px), (pointer: coarse)').matches ?? false;
    const dpr = isMobile ? 1 : Math.min(window.devicePixelRatio || 1, 1.5);
    const sprites = HUES.map(makeSprite);
    const stepMs = isMobile ? 1000 / 30 : 0; // móvil: dibuja a 30 fps y deja libre el hilo para el scroll

    let w = 0, h = 0, raf = 0, last = performance.now(), lastDraw = 0, nextMeteor = 0;
    let quality = 2;              // 2 = completo, 1 = reducido, 0 = estático
    let slowMs = 0;               // tiempo acumulado con frames lentos
    let stars: Star[] = [];
    const meteors: Meteor[] = [];

    const targetCount = () => {
      const base = isMobile ? 34 : Math.min(130, Math.max(60, (w * h) / 13000));
      return Math.round(base * (quality === 2 ? 1 : 0.5));
    };

    const build = () => {
      const n = targetCount();
      stars = Array.from({ length: n }, () => ({
        x: Math.random() * w,
        y: Math.random() * h,
        r: 3 + Math.random() * 7,
        phase: Math.random() * Math.PI * 2,
        speed: 0.6 + Math.random() * 1.8,
        sprite: Math.floor(Math.random() * sprites.length),
        cross: !isMobile && Math.random() < 0.12,
      }));
    };

    const resize = () => {
      w = window.innerWidth; h = window.innerHeight;
      canvas.width = Math.round(w * dpr); canvas.height = Math.round(h * dpr);
      canvas.style.width = w + 'px'; canvas.style.height = h + 'px';
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      build();
      if (quality === 0) drawFrame(performance.now(), 0);
    };

    const spawnMeteor = () => {
      const angle = (Math.PI / 180) * (105 + Math.random() * 25);
      const speed = 380 + Math.random() * 300;
      meteors.push({
        x: Math.random() * (w + 200) - 50, y: -30,
        vx: Math.cos(angle) * speed, vy: Math.sin(angle) * speed,
        len: 80 + Math.random() * 100, w: 1 + Math.random() * 1.2,
        life: 0, max: (h + 80) / (Math.sin(angle) * speed),
        hue: Math.random() < 0.7 ? 24 + Math.random() * 20 : 268 + Math.random() * 20,
      });
    };

    const drawFrame = (now: number, dt: number) => {
      ctx.clearRect(0, 0, w, h);
      const t = now / 1000;

      for (let i = 0; i < stars.length; i++) {
        const s = stars[i];
        const a = 0.3 + 0.7 * (0.5 + 0.5 * Math.sin(t * s.speed + s.phase));
        ctx.globalAlpha = quality === 0 ? 0.7 : a;
        const d = s.r * 2;
        ctx.drawImage(sprites[s.sprite], s.x - s.r, s.y - s.r, d, d);
        if (s.cross && quality === 2) {
          ctx.strokeStyle = 'rgba(255,237,213,0.9)';
          ctx.lineWidth = 0.7;
          const l = s.r * 0.9 * a;
          ctx.beginPath();
          ctx.moveTo(s.x - l, s.y); ctx.lineTo(s.x + l, s.y);
          ctx.moveTo(s.x, s.y - l); ctx.lineTo(s.x, s.y + l);
          ctx.stroke();
        }
      }
      ctx.globalAlpha = 1;
      if (quality === 0) return;

      const maxMeteors = isMobile ? 2 : 4;
      if (now > nextMeteor && meteors.length < maxMeteors) {
        spawnMeteor();
        nextMeteor = now + (isMobile ? 1100 : 500) + Math.random() * 1400;
      }
      for (let i = meteors.length - 1; i >= 0; i--) {
        const m = meteors[i];
        m.life += dt;
        m.x += m.vx * dt; m.y += m.vy * dt;
        if (m.life > m.max || m.y > h + 60) { meteors.splice(i, 1); continue; }
        const k = Math.min(1, m.life / 0.25) * Math.min(1, (m.max - m.life) / 0.4 + 0.3);
        const n = Math.hypot(m.vx, m.vy);
        const tx = m.x - (m.vx / n) * m.len, ty = m.y - (m.vy / n) * m.len;
        const g = ctx.createLinearGradient(m.x, m.y, tx, ty);
        g.addColorStop(0, `hsla(${m.hue},100%,92%,${0.95 * k})`);
        g.addColorStop(0.3, `hsla(${m.hue},95%,68%,${0.55 * k})`);
        g.addColorStop(1, `hsla(${m.hue},90%,55%,0)`);
        ctx.strokeStyle = g; ctx.lineWidth = m.w; ctx.lineCap = 'round';
        ctx.beginPath(); ctx.moveTo(m.x, m.y); ctx.lineTo(tx, ty); ctx.stroke();
        ctx.globalAlpha = 0.9 * k;
        const hs = m.w * 9;
        ctx.drawImage(sprites[m.hue < 100 ? 1 : 4], m.x - hs, m.y - hs, hs * 2, hs * 2);
        ctx.globalAlpha = 1;
      }
    };

    const frame = (now: number) => {
      raf = requestAnimationFrame(frame);
      const raw = now - last;

      // Ajuste automático: si va por debajo de ~50 fps de forma sostenida, baja la calidad
      if (quality > 0 && raw > 22 && raw < 250) {
        slowMs += raw;
        if (slowMs > 1500) {
          quality -= 1; slowMs = 0;
          meteors.length = 0;
          build();
          if (quality === 0) { cancelAnimationFrame(raf); drawFrame(now, 0); return; } // queda estático
        }
      } else if (raw <= 22) {
        slowMs = Math.max(0, slowMs - raw);
      }

      if (stepMs && now - lastDraw < stepMs - 2) { last = now; return; }
      const dt = Math.min((now - (lastDraw || now - 16)) / 1000, 0.06);
      last = now; lastDraw = now;
      drawFrame(now, dt);
    };

    const onVisibility = () => {
      cancelAnimationFrame(raf);
      if (!document.hidden && quality > 0) { last = performance.now(); lastDraw = 0; raf = requestAnimationFrame(frame); }
    };

    let resizeTimer = 0;
    const onResize = () => { clearTimeout(resizeTimer); resizeTimer = window.setTimeout(resize, 150); };

    resize();
    window.addEventListener('resize', onResize, { passive: true });
    document.addEventListener('visibilitychange', onVisibility);
    raf = requestAnimationFrame(frame);
    return () => {
      cancelAnimationFrame(raf);
      clearTimeout(resizeTimer);
      window.removeEventListener('resize', onResize);
      document.removeEventListener('visibilitychange', onVisibility);
    };
  }, []);

  return <canvas ref={ref} aria-hidden="true" className="fixed inset-0 z-0 pointer-events-none" />;
};
