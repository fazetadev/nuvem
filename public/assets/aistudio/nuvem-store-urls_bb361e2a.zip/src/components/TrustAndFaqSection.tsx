import { useI18n } from '../i18n.tsx';
import React, { useState } from 'react';
import { ChevronDown, ShieldCheck, Zap, HeartHandshake, Award, HelpCircle } from 'lucide-react';

export const TrustAndFaqSection: React.FC = () => {
  const { t } = useI18n();
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const faqs = [
    {
      q: t('¿Piden mi contraseña o datos de acceso a Free Fire?'),
      a: t('Nunca. En Nuvem Store jamás solicitamos contraseñas, correos de Google, Facebook ni accesos privados. La recarga se realiza de forma 100% oficial mediante tu UID (ID de Jugador público). Tu cuenta permanece completamente segura en tus manos.'),
    },
    {
      q: t('¿Cuánto tiempo tarda en llegar mi recarga de diamantes?'),
      a: t('El proceso toma en promedio entre 1 y 3 minutos una vez validado tu pago. En casos de eventos masivos o actualizaciones de Garena puede tardar hasta 5 minutos como máximo.'),
    },
    {
      q: t('¿Qué medios de pago puedo utilizar en Colombia?'),
      a: t('Aceptamos Nequi, transferencia Bancolombia y PayPal. Sin comisiones ocultas.'),
    },
    {
      q: t('¿Puedo sufrir baneo o suspensión en Free Fire?'),
      a: t('Para nada. Nuestras recargas se procesan mediante las pasarelas oficiales de distribución autorizadas de Garena. Cuentas con 0% riesgo de baneo o diamantes negativos.'),
    },
    {
      q: t('¿Puedo ver los precios en dólares?'),
      a: t('Sí. Usa el botón COP / USD del menú: la página cambia de idioma y muestra los precios en dólares con una tasa de referencia. El monto final se confirma contigo por WhatsApp antes de pagar.'),
    },
    {
      q: t('¿Qué hago si escribí mal mi ID o tengo un problema?'),
      a: t('Nuestro equipo de soporte humano está disponible todos los días en WhatsApp (+57 301 688 6549). Si nos contactas inmediatamente antes de procesar el pedido, corregimos tu ID al instante.'),
    },
  ];

  const toggleFaq = (idx: number) => {
    setOpenIndex(openIndex === idx ? null : idx);
  };

  return (
    <section id="faq" className="py-12 sm:py-16 border-b border-purple-950/60">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Trust Badges Bar */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-16">
          <div className="p-6 rounded-2xl bg-[#110d21] border border-purple-900/40 flex items-start gap-4">
            <div className="w-12 h-12 rounded-xl bg-purple-900/40 border border-purple-700/40 flex items-center justify-center text-purple-400 shrink-0">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-display text-base font-bold text-white mb-1">
                {t("Garantía Anti-Ban 100%")}
              </h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                {t("Recargas autorizadas por canal oficial. Cero riesgos de diamantes negativos en tu cuenta de Garena.")}
              </p>
            </div>
          </div>

          <div className="p-6 rounded-2xl bg-[#110d21] border border-purple-900/40 flex items-start gap-4">
            <div className="w-12 h-12 rounded-xl bg-purple-900/40 border border-purple-700/40 flex items-center justify-center text-purple-400 shrink-0">
              <Zap className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-display text-base font-bold text-white mb-1">
                {t("Acreditación en Minutos")}
              </h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                {t("Sistema automatizado que valida pagos y despacha diamantes en tiempo récord los 7 días de la semana.")}
              </p>
            </div>
          </div>

          <div className="p-6 rounded-2xl bg-[#110d21] border border-purple-900/40 flex items-start gap-4">
            <div className="w-12 h-12 rounded-xl bg-purple-900/40 border border-purple-700/40 flex items-center justify-center text-purple-400 shrink-0">
              <HeartHandshake className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-display text-base font-bold text-white mb-1">
                {t("Atención Real en Colombia")}
              </h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                {t("Soporte en español por WhatsApp para resolver dudas, revisar comprobantes y verificar pedidos al instante.")}
              </p>
            </div>
          </div>
        </div>

        {/* 2-Column Section: Shield Image + FAQ Accordion */}
        <div className="max-w-3xl mx-auto">
          
          {/* Right Column: FAQ Accordion */}
          <div className="space-y-4">
            <div className="space-y-1 mb-6">
              <div className="inline-flex items-center gap-1.5 text-xs font-bold text-purple-400 uppercase tracking-wider">
                <HelpCircle className="w-4 h-4" />
                <span>{t("Resuelve tus Dudas")}</span>
              </div>
              <h2 className="font-display text-2xl sm:text-3xl font-black title-grad tracking-tight">
                {t("Preguntas Frecuentes")}
              </h2>
            </div>

            <div className="space-y-3">
              {faqs.map((faq, idx) => {
                const isOpen = openIndex === idx;

                return (
                  <div
                    key={idx}
                    className={`rounded-2xl transition-colors border ${
                      isOpen
                        ? 'bg-[#140f26] border-purple-700/60'
                        : 'bg-[#0e0b1a] border-purple-900/40 hover:border-purple-800/60'
                    }`}
                  >
                    <button
                      type="button"
                      onClick={() => toggleFaq(idx)}
                      className="w-full p-4 sm:p-5 flex items-center justify-between gap-4 text-left cursor-pointer"
                      aria-expanded={isOpen}
                    >
                      <span className="font-display text-sm sm:text-base font-bold text-white tracking-tight">
                        {faq.q}
                      </span>
                      <ChevronDown
                        className={`w-5 h-5 text-purple-400 transition-transform duration-200 shrink-0 ${
                          isOpen ? 'rotate-180 text-purple-300' : ''
                        }`}
                      />
                    </button>

                    {isOpen && (
                      <div className="px-4 pb-5 sm:px-5 text-xs sm:text-sm text-slate-300 leading-relaxed border-t border-purple-950/60 pt-3">
                        {faq.a}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
