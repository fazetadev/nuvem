import { useI18n } from '../i18n.tsx';
import { DiamondIcon } from "./DiamondIcon";
import { IMAGES } from "../config/images";
import type { GameId } from "../types/store.ts";
import React from 'react';
import { Check, Gem, Crown } from 'lucide-react';
import { DiamondPackage } from '../types/store.ts';
import { DIAMOND_PACKAGES, ROBLOX_PACKAGES, GAME_INFO, formatNumber } from '../utils/rechargeLogic.ts';

interface PackagesGridProps {
  selectedPackage: DiamondPackage | null;
  onSelectPackage: (pkg: DiamondPackage) => void;
  game: GameId;
}

export const PackagesGrid: React.FC<PackagesGridProps> = ({
  selectedPackage,
  onSelectPackage,
  game,
}) => {
  const { t, formatPrice, lang, rate } = useI18n();
  const info = GAME_INFO[game];
  const isRoblox = game === 'roblox';

  const currentList = isRoblox ? ROBLOX_PACKAGES : DIAMOND_PACKAGES;

  return (
    <div id="paquetes" className="p-5 sm:p-7 rounded-3xl bg-[#120f1e]/90 border border-purple-900/40 backdrop-blur-md shadow-xl shadow-purple-950/20 space-y-5">
      
      {/* Step Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-purple-900/30">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-xl bg-purple-600/30 border border-purple-500/40 flex items-center justify-center text-purple-300 font-bold font-mono text-sm">
            {isRoblox ? 1 : 2}
          </div>
          <div>
            <h2 className="text-lg sm:text-xl font-bold text-white tracking-tight">
              {t(info.packagesTitle)}
            </h2>
            <p className="text-xs text-purple-300/80">
              {lang === 'en'
                ? t('Precios en dólares (USD) · tasa referencial 1 USD ≈ {rate} COP · Entrega directa oficial', { rate: new Intl.NumberFormat('es-CO', { maximumFractionDigits: 0 }).format(rate) })
                : t('Tarifas fijas en Pesos Colombianos (COP) · Entrega directa oficial')}
            </p>
          </div>
        </div>

      </div>

      {/* Product Packages Grid (Super Professional Compact Grid) */}
      <div className={`grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3`}>
        {currentList.map((pkg) => {
          const isSelected = selectedPackage?.id === pkg.id;

          return (
            <div
              key={pkg.id}
              role="button"
              tabIndex={0}
              onClick={() => onSelectPackage(pkg)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                  e.preventDefault();
                  onSelectPackage(pkg);
                }
              }}
              className={`relative rounded-xl p-3.5 text-left transition-all duration-150 cursor-pointer flex flex-col justify-between group select-none min-h-[120px] sm:min-h-[135px] ${
                isSelected
                  ? 'bg-gradient-to-b from-purple-900/70 via-[#1b1430] to-[#120d22] border-2 border-purple-400 shadow-md shadow-purple-900/50 ring-1 ring-purple-400/40 -translate-y-0.5'
                  : 'bg-[#0d0a17] hover:bg-[#151024] border border-purple-900/50 hover:border-purple-600/60'
              }`}
            >
              {/* Optional Subtle Corner Badge */}
              {pkg.tag && (
                <div className="absolute -top-2 right-2 px-2 py-0.5 rounded-md text-[9px] font-bold uppercase tracking-wider bg-purple-600 text-white shadow-sm border border-purple-400/40">
                  {t(pkg.tag)}
                </div>
              )}

              {/* Card Top: Amount & Jewel */}
              <div className="flex items-center justify-between gap-1.5 pt-0.5">
                <div className="flex items-center gap-1.5">
                  <span className="text-lg sm:text-xl font-extrabold text-white tracking-tight">
                    {formatNumber(pkg.diamonds)}
                  </span>
                  {isRoblox ? (
                    <DiamondIcon src={IMAGES.robuxIcon} alt={t("Robux")} className="w-6 h-6 sm:w-7 sm:h-7" />
                  ) : (
                    <DiamondIcon className="w-8 h-8 sm:w-9 sm:h-9" />
                  )}
                </div>

                {isSelected ? (
                  <div className="w-5 h-5 rounded-full bg-purple-500 text-white flex items-center justify-center shrink-0">
                    <Check className="w-3 h-3 stroke-[3]" />
                  </div>
                ) : (
                  <div className="w-5 h-5 rounded-full border border-purple-900/70 group-hover:border-purple-500/50 flex items-center justify-center shrink-0">
                    <div className="w-1.5 h-1.5 rounded-full bg-purple-800/60 group-hover:bg-purple-500" />
                  </div>
                )}
              </div>

              {/* Middle Mini Label */}
              <div className="my-2">
                <span className="text-[11px] text-slate-400 block truncate font-medium">
                  {pkg.category === 'diamonds' ? (isRoblox ? t('Entrega Directa') : t('Recarga Directa')) : t(pkg.description)}
                </span>
              </div>

              {/* Price in COP */}
              <div className="pt-2 border-t border-purple-900/40 flex items-center justify-between">
                <span className="font-mono text-xs sm:text-sm font-bold text-purple-200 tabular-nums">
                  {formatPrice(pkg.priceCOP, pkg.priceUSD)}
                </span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Selected package reassurance bar (Compact) */}
      {selectedPackage && (
        <div className="px-4 py-3 rounded-xl bg-purple-950/40 border border-purple-800/40 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
          <div className="flex items-center gap-2">
            <Gem className="w-4 h-4 text-purple-400 shrink-0" />
            <span className="text-slate-300">
              {t("Seleccionado:")} <strong className="text-white font-bold">{formatNumber(selectedPackage.diamonds)} {t(info.unit)}</strong> ({formatPrice(selectedPackage.priceCOP, selectedPackage.priceUSD)})
            </span>
          </div>
          <span className="text-purple-300/90 font-medium">
            {t('Elige tu método de pago en el Paso {n}', { n: isRoblox ? 2 : 3 })}
          </span>
        </div>
      )}

    </div>
  );
};
