import { useI18n } from '../i18n.tsx';
import { IMAGES } from "../config/images";
import React, { useState, useEffect } from 'react';
import { Sparkles, Menu, X } from 'lucide-react';

interface HeaderProps {
  onOpenTracker: () => void;
  onScrollToRecharge: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onOpenTracker, onScrollToRecharge }) => {
  const { t, lang, setLang } = useI18n();
  const [menuOpen, setMenuOpen] = useState(false);
  useEffect(() => {
    if (!menuOpen) return;
    const close = () => setMenuOpen(false);
    window.addEventListener('scroll', close, { passive: true, once: true });
    return () => window.removeEventListener('scroll', close);
  }, [menuOpen]);
  const links: [string, string][] = [
    ['#recargar', 'Paquetes de Recarga'],
    ['#como-funciona', '¿Cómo Funciona?'],
    ['#metodos-pago', 'Medios de Pago'],
    ['#faq', 'Preguntas Frecuentes'],
  ];
  return (
    <header className="sticky top-0 z-40 w-full backdrop-blur-xl bg-[#0b0a12]/85 border-b border-purple-900/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 sm:h-18 grid grid-cols-[auto_1fr] lg:grid-cols-[1fr_auto_1fr] items-center gap-4 sm:gap-8">
        {/* Zone 1: Brand Zone */}
        <a href="/" className="flex items-center gap-2 text-left shrink-0 group justify-self-start">
          <div className="w-9 h-9 rounded-xl overflow-hidden bg-gradient-to-tr from-purple-700 via-purple-600 to-indigo-500 flex items-center justify-center shadow-md shadow-purple-600/30 group-hover:shadow-purple-500/50 transition-all shrink-0">
            <img decoding="async" src={IMAGES.logo} alt={t("Nuvem Store")} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
          </div>
          <span className="font-display text-base sm:text-xl font-black tracking-tight text-white uppercase whitespace-nowrap">
            {t("nuvem")} <span className="text-purple-400">{t("store")}</span>
          </span>
        </a>

        {/* Zone 2: Navigation Links (single line, clean typography) */}
        <nav className="hidden lg:flex items-center gap-7 text-sm font-medium text-slate-300">
          <button
            onClick={onScrollToRecharge}
            className="hover:text-purple-300 transition-colors whitespace-nowrap shrink-0 text-left cursor-pointer"
          >
            {t("Paquetes de Recarga")}
          </button>
          <a
            href="#como-funciona"
            className="hover:text-purple-300 transition-colors whitespace-nowrap shrink-0"
          >
            {t("¿Cómo Funciona?")}
          </a>
          <a
            href="#metodos-pago"
            className="hover:text-purple-300 transition-colors whitespace-nowrap shrink-0"
          >
            {t("Medios de Pago")}
          </a>
          <a
            href="#faq"
            className="hover:text-purple-300 transition-colors whitespace-nowrap shrink-0"
          >
            {t("Preguntas Frecuentes")}
          </a>
        </nav>

        {/* Zone 3: Primary Action */}
        <div className="flex items-center gap-2 sm:gap-3 shrink-0 justify-self-end">
          <div
            role="group"
            aria-label={t('Idioma y moneda')}
            className="lang-switch flex items-center p-0.5 rounded-full border border-white/15 bg-white/5 text-[11px] font-bold"
          >
            {([
              ['es', 'COP', 'ES'],
              ['en', 'USD', 'EN'],
            ] as const).map(([code, cur, lg]) => (
              <button
                key={code}
                type="button"
                onClick={() => setLang(code)}
                aria-pressed={lang === code}
                title={code === 'es' ? 'Español · Pesos colombianos (COP)' : 'English · US dollars (USD)'}
                className={`px-2.5 sm:px-3 py-1.5 rounded-full transition-all cursor-pointer whitespace-nowrap ${
                  lang === code
                    ? 'bg-gradient-to-b from-orange-400 to-orange-600 text-white shadow-[inset_0_1px_0_rgba(255,255,255,0.45),0_4px_14px_rgba(249,115,22,0.45)]'
                    : 'text-slate-300 hover:text-white'
                }`}
              >
                {cur}<span className="hidden sm:inline opacity-70"> · {lg}</span>
              </button>
            ))}
          </div>
          <button
            type="button"
            onClick={() => setMenuOpen((v) => !v)}
            aria-label="Menu"
            aria-expanded={menuOpen}
            className="lg:hidden p-2 rounded-xl border border-white/15 bg-white/5 text-slate-200"
          >
            {menuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>

          <button
            onClick={onScrollToRecharge}
            className="px-3.5 py-2 sm:px-5 sm:py-2.5 text-xs sm:text-sm font-bold text-white bg-gradient-to-r from-purple-600 via-purple-500 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 rounded-xl shadow-lg shadow-purple-600/30 hover:shadow-purple-500/50 transition-all duration-200 transform hover:-translate-y-0.5 whitespace-nowrap cursor-pointer flex items-center gap-1.5"
          >
            <Sparkles className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-purple-200" />
            <span className="hidden sm:inline">{t("Recargar Ahora")}</span>
            <span className="sm:hidden">{t("Recargar")}</span>
          </button>
        </div>
      </div>
      {menuOpen && (
        <nav className="lg:hidden border-t border-white/10 px-4 py-3 grid gap-1 bg-[#0b0a12]/95">
          {links.map(([href, label]) => (
            <a key={href} href={href} onClick={() => setMenuOpen(false)} className="px-3 py-3 rounded-xl text-sm font-semibold text-slate-200 hover:bg-white/5">
              {t(label)}
            </a>
          ))}
        </nav>
      )}
    </header>
  );
};
