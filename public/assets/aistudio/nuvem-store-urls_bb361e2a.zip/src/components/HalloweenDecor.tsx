import React from 'react';

type P = { className?: string; style?: React.CSSProperties };

export const Pumpkin: React.FC<P> = ({ className, style }) => (
  <svg viewBox="0 0 120 110" className={className} style={style} aria-hidden="true">
    <defs>
      <radialGradient id="pk-body" cx="50%" cy="40%" r="65%">
        <stop offset="0" stopColor="#fdba74" />
        <stop offset="0.55" stopColor="#f97316" />
        <stop offset="1" stopColor="#9a3412" />
      </radialGradient>
      <radialGradient id="pk-glow" cx="50%" cy="50%" r="50%">
        <stop offset="0" stopColor="#fde047" />
        <stop offset="1" stopColor="#f59e0b" />
      </radialGradient>
    </defs>
    <ellipse cx="60" cy="102" rx="38" ry="5" fill="#000" opacity="0.35" />
    <ellipse cx="34" cy="62" rx="26" ry="40" fill="url(#pk-body)" />
    <ellipse cx="86" cy="62" rx="26" ry="40" fill="url(#pk-body)" />
    <ellipse cx="60" cy="62" rx="30" ry="42" fill="url(#pk-body)" />
    <path d="M60 22 C 52 40, 52 84, 60 102" stroke="#9a3412" strokeWidth="2" fill="none" opacity="0.55" />
    <path d="M42 26 C 30 46, 30 80, 42 98" stroke="#9a3412" strokeWidth="2" fill="none" opacity="0.4" />
    <path d="M78 26 C 90 46, 90 80, 78 98" stroke="#9a3412" strokeWidth="2" fill="none" opacity="0.4" />
    <path d="M56 24 C 56 14, 60 8, 68 4 C 66 12, 66 18, 66 24 Z" fill="#4d7c0f" />
    <path d="M40 54 L52 62 L36 66 Z" fill="url(#pk-glow)" />
    <path d="M80 54 L68 62 L84 66 Z" fill="url(#pk-glow)" />
    <path d="M60 66 L55 74 L65 74 Z" fill="url(#pk-glow)" />
    <path d="M36 78 Q60 100 84 78 L78 76 L72 84 L66 77 L60 86 L54 77 L48 84 L42 76 Z" fill="url(#pk-glow)" />
  </svg>
);

export const Bat: React.FC<P> = ({ className, style }) => (
  <svg viewBox="0 0 100 50" className={className} style={style} aria-hidden="true">
    <path
      d="M50 16 L45 6 L48 18 C 38 10, 20 8, 2 22 C 14 20, 20 26, 26 38 C 32 30, 40 30, 46 40 L50 32 L54 40 C 60 30, 68 30, 74 38 C 80 26, 86 20, 98 22 C 80 8, 62 10, 52 18 L55 6 Z"
      fill="currentColor"
    />
    <circle cx="47" cy="22" r="1.2" fill="#fde047" />
    <circle cx="53" cy="22" r="1.2" fill="#fde047" />
  </svg>
);

export const Ghost: React.FC<P> = ({ className, style }) => (
  <svg viewBox="0 0 80 100" className={className} style={style} aria-hidden="true">
    <defs>
      <linearGradient id="gh" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stopColor="#ffffff" />
        <stop offset="1" stopColor="#c4b5fd" />
      </linearGradient>
    </defs>
    <path
      d="M10 94 V40 C 10 16, 24 4, 40 4 C 56 4, 70 16, 70 40 V94 L60 84 L50 94 L40 84 L30 94 L20 84 Z"
      fill="url(#gh)"
    />
    <ellipse cx="30" cy="40" rx="5" ry="7" fill="#1e1b4b" />
    <ellipse cx="50" cy="40" rx="5" ry="7" fill="#1e1b4b" />
    <ellipse cx="40" cy="58" rx="6" ry="8" fill="#1e1b4b" />
  </svg>
);

export const Cobweb: React.FC<P> = ({ className, style }) => (
  <svg viewBox="0 0 160 160" className={className} style={style} aria-hidden="true">
    <g stroke="currentColor" strokeWidth="1" fill="none" strokeLinecap="round">
      <path d="M0 0 L160 0" /><path d="M0 0 L140 50" /><path d="M0 0 L110 110" />
      <path d="M0 0 L50 140" /><path d="M0 0 L0 160" />
      <path d="M30 0 Q 28 22 0 30" /><path d="M60 0 Q 56 44 0 60" />
      <path d="M95 0 Q 88 70 0 95" /><path d="M130 0 Q 118 96 0 130" />
    </g>
  </svg>
);

export const Moon: React.FC<P> = ({ className, style }) => (
  <svg viewBox="0 0 200 200" className={className} style={style} aria-hidden="true">
    <defs>
      <radialGradient id="moon-g" cx="40%" cy="38%" r="70%">
        <stop offset="0" stopColor="#fffbeb" />
        <stop offset="0.7" stopColor="#fde68a" />
        <stop offset="1" stopColor="#f59e0b" />
      </radialGradient>
    </defs>
    <circle cx="100" cy="100" r="62" fill="url(#moon-g)" />
    <circle cx="78" cy="82" r="10" fill="#f59e0b" opacity="0.28" />
    <circle cx="118" cy="110" r="14" fill="#f59e0b" opacity="0.22" />
    <circle cx="96" cy="128" r="7" fill="#f59e0b" opacity="0.25" />
  </svg>
);

// Cementerio en silueta para la base de la página
export const Graveyard: React.FC<P> = ({ className }) => (
  <svg viewBox="0 0 1200 140" preserveAspectRatio="none" className={className} aria-hidden="true">
    <path
      d="M0 140 V92 C 60 80 100 100 160 92 C 220 84 260 100 330 94 C 420 86 480 100 560 94 C 660 86 720 100 800 92 C 880 84 940 98 1020 92 C 1100 86 1150 96 1200 90 V140 Z"
      fill="#0a0710"
    />
    {[90, 230, 410, 640, 790, 960, 1100].map((x, i) => (
      <g key={x} fill="#150f22" stroke="#2a1f42" strokeWidth="1.5">
        {i % 3 === 0 ? (
          <path d={`M${x - 6} 104 V60 H${x - 18} V50 H${x - 6} V36 H${x + 6} V50 H${x + 18} V60 H${x + 6} V104 Z`} />
        ) : (
          <path d={`M${x - 16} 104 V62 C ${x - 16} 40 ${x + 16} 40 ${x + 16} 62 V104 Z`} />
        )}
      </g>
    ))}
    <g stroke="#150f22" strokeWidth="5" fill="none" strokeLinecap="round">
      <path d="M170 100 C 172 70 160 56 150 36 M162 62 C 150 56 142 54 136 44 M166 52 C 176 46 182 40 186 30" />
      <path d="M1040 100 C 1038 72 1050 58 1058 38 M1048 64 C 1060 58 1068 56 1074 46" />
    </g>
  </svg>
);

// Capa de fondo: luna, niebla, murciélagos volando y fantasmas flotando
export const HalloweenBackdrop: React.FC = () => (
  <div className="fixed inset-0 z-0 pointer-events-none overflow-hidden" aria-hidden="true">
    <div className="absolute -top-10 -right-10 sm:top-16 sm:right-[6%] w-44 sm:w-64 opacity-90 hw-moon">
      <Moon className="w-full h-full" />
    </div>
    <div className="absolute inset-x-0 bottom-0 h-72 bg-gradient-to-t from-orange-600/10 via-purple-900/10 to-transparent" />
    <div className="absolute inset-x-0 bottom-0 h-40 hw-fog" />

    {[
      { top: '14%', size: 'w-12', dur: '19s', delay: '0s' },
      { top: '28%', size: 'w-9', dur: '25s', delay: '6s' },
      { top: '48%', size: 'w-14', dur: '22s', delay: '12s' },
      { top: '66%', size: 'w-8', dur: '28s', delay: '3s' },
    ].map((b, i) => (
      <div key={i} className={`absolute left-0 hw-bat-path hw-bat-${i}`} style={{ top: b.top, animationDuration: b.dur, animationDelay: b.delay }}>
        <div className="hw-bat-bob">
          <Bat className={`${b.size} text-[#0a0710] hw-bat-flap`} style={{ animationDelay: `${i * 0.13}s` }} />
        </div>
      </div>
    ))}

    <Ghost className="absolute left-[5%] top-[38%] w-12 sm:w-16 opacity-40 hw-ghost" style={{ animationDelay: '0s' }} />
    <Ghost className="absolute right-[8%] top-[60%] w-10 sm:w-14 opacity-30 hw-ghost" style={{ animationDelay: '2.5s' }} />
  </div>
);
